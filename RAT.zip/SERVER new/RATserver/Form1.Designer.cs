﻿namespace RATserver
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button1 = new RATserver.RoundedButton();
            this.button2 = new RATserver.RoundedButton();
            this.label24 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button5 = new RATserver.RoundedButton();
            this.button6 = new RATserver.RoundedButton();
            this.button4 = new RATserver.RoundedButton();
            this.button3 = new RATserver.RoundedButton();
            this.label12 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.roundedButton5 = new RATserver.RoundedButton();
            this.roundedButton4 = new RATserver.RoundedButton();
            this.roundedButton3 = new RATserver.RoundedButton();
            this.roundedButton2 = new RATserver.RoundedButton();
            this.roundedButton7 = new RATserver.RoundedButton();
            this.roundedButton6 = new RATserver.RoundedButton();
            this.roundedButton1 = new RATserver.RoundedButton();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.roundedButton8 = new RATserver.RoundedButton();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.killToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button15 = new RATserver.RoundedButton();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.lblQualityShow = new System.Windows.Forms.Label();
            this.lblChooseScreen = new System.Windows.Forms.Label();
            this.cmboChooseScreen = new System.Windows.Forms.ComboBox();
            this.btnCountScreens = new System.Windows.Forms.Button();
            this.btnStartTaskManager = new System.Windows.Forms.Button();
            this.txtBControlKeyboard = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.btnFullScreenMode = new System.Windows.Forms.Button();
            this.checkBoxrKeyboard = new System.Windows.Forms.CheckBox();
            this.checkBoxrMouse = new System.Windows.Forms.CheckBox();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.button25 = new RATserver.RoundedButton();
            this.roundedButton10 = new RATserver.RoundedButton();
            this.listView4 = new System.Windows.Forms.ListView();
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.button27 = new RATserver.RoundedButton();
            this.roundedButton12 = new RATserver.RoundedButton();
            this.listView5 = new System.Windows.Forms.ListView();
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.listDrivesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enterDirectoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.moveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.currentDirectoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectedDirectoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.executeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uploadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.currentDirectoryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.selectedDirectoryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.downloadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.attributesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hideToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.directoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.contextMenuStrip3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(909, 576);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Click += new System.EventHandler(this.tabControl1_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Black;
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.listView1);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.ForeColor = System.Drawing.Color.White;
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(901, 550);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Главная";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(584, 30);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(292, 53);
            this.button1.TabIndex = 9;
            this.button1.Text = "Запустить сервер";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.button1.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.button1.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.button1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(584, 108);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(292, 53);
            this.button2.TabIndex = 8;
            this.button2.Text = "Управлять выбранными клиентами";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            this.button2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.button2.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.button2.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.button2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(8, 70);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(76, 13);
            this.label24.TabIndex = 6;
            this.label24.Text = "Подключения";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(557, 178);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 20);
            this.label2.TabIndex = 4;
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.Black;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listView1.ForeColor = System.Drawing.Color.White;
            this.listView1.FullRowSelect = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(10, 105);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(541, 384);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID клиента";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Имя компьютера";
            this.columnHeader2.Width = 113;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "IP клиента";
            this.columnHeader3.Width = 115;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Время у клиента";
            this.columnHeader4.Width = 123;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Антивирус";
            this.columnHeader5.Width = 116;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(6, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Статус сервера";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Black;
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.button6);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.richTextBox1);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.comboBox3);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.textBox3);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.comboBox2);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Controls.Add(this.textBox2);
            this.tabPage2.Controls.Add(this.textBox1);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(901, 550);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Меню оповещений";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Black;
            this.button5.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button5.Location = new System.Drawing.Point(471, 67);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(292, 53);
            this.button5.TabIndex = 21;
            this.button5.Text = "Проиграть";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            this.button5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.button5.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.button5.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.button5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Black;
            this.button6.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button6.Location = new System.Drawing.Point(498, 399);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(292, 53);
            this.button6.TabIndex = 21;
            this.button6.Text = "Прочитать";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            this.button6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.button6.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.button6.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.button6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Black;
            this.button4.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.Location = new System.Drawing.Point(29, 322);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(292, 53);
            this.button4.TabIndex = 21;
            this.button4.Text = "Проиграть";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            this.button4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.button4.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.button4.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.button4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Black;
            this.button3.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.Location = new System.Drawing.Point(46, 175);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(292, 53);
            this.button3.TabIndex = 21;
            this.button3.Text = "Отправить";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            this.button3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.button3.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.button3.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.button3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(428, 195);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 13);
            this.label12.TabIndex = 19;
            this.label12.Text = "Текст";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(471, 192);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(374, 201);
            this.richTextBox1.TabIndex = 18;
            this.richTextBox1.Text = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(414, 161);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(194, 13);
            this.label11.TabIndex = 17;
            this.label11.Text = "Microsoft чтение текста (только англ)";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Error",
            "Warning",
            "Information",
            "Beep"});
            this.comboBox3.Location = new System.Drawing.Point(471, 40);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(292, 21);
            this.comboBox3.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(414, 12);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "Системные звуки";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(46, 296);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(232, 20);
            this.textBox3.TabIndex = 11;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(20, 299);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "Hz";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 257);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Проиграть частоту";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 147);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Кнопки";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 115);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Иконка";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Текст";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Заголовок";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Ok",
            "Yes No",
            "Ok Cancel",
            "Abort Retry Ignore",
            "Yes No Cancel"});
            this.comboBox2.Location = new System.Drawing.Point(89, 139);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(232, 21);
            this.comboBox2.TabIndex = 4;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Error",
            "Warning",
            "Information",
            "Question",
            "None"});
            this.comboBox1.Location = new System.Drawing.Point(89, 112);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(232, 21);
            this.comboBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(89, 77);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(232, 20);
            this.textBox2.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(89, 41);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(232, 20);
            this.textBox1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Message Box";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Black;
            this.tabPage3.Controls.Add(this.roundedButton5);
            this.tabPage3.Controls.Add(this.roundedButton4);
            this.tabPage3.Controls.Add(this.roundedButton3);
            this.tabPage3.Controls.Add(this.roundedButton2);
            this.tabPage3.Controls.Add(this.roundedButton7);
            this.tabPage3.Controls.Add(this.roundedButton6);
            this.tabPage3.Controls.Add(this.roundedButton1);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(901, 550);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Дисковод и панель задач";
            // 
            // roundedButton5
            // 
            this.roundedButton5.BackColor = System.Drawing.Color.Black;
            this.roundedButton5.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.roundedButton5.Location = new System.Drawing.Point(47, 309);
            this.roundedButton5.Name = "roundedButton5";
            this.roundedButton5.Size = new System.Drawing.Size(292, 53);
            this.roundedButton5.TabIndex = 22;
            this.roundedButton5.Text = "Меню пуск: видно";
            this.roundedButton5.UseVisualStyleBackColor = false;
            this.roundedButton5.Click += new System.EventHandler(this.button11_Click);
            this.roundedButton5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.roundedButton5.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.roundedButton5.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.roundedButton5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // roundedButton4
            // 
            this.roundedButton4.BackColor = System.Drawing.Color.Black;
            this.roundedButton4.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.roundedButton4.Location = new System.Drawing.Point(47, 250);
            this.roundedButton4.Name = "roundedButton4";
            this.roundedButton4.Size = new System.Drawing.Size(292, 53);
            this.roundedButton4.TabIndex = 22;
            this.roundedButton4.Text = "Иконки в трее: видно";
            this.roundedButton4.UseVisualStyleBackColor = false;
            this.roundedButton4.Click += new System.EventHandler(this.button10_Click);
            this.roundedButton4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.roundedButton4.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.roundedButton4.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.roundedButton4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // roundedButton3
            // 
            this.roundedButton3.BackColor = System.Drawing.Color.Black;
            this.roundedButton3.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.roundedButton3.Location = new System.Drawing.Point(47, 191);
            this.roundedButton3.Name = "roundedButton3";
            this.roundedButton3.Size = new System.Drawing.Size(292, 53);
            this.roundedButton3.TabIndex = 22;
            this.roundedButton3.Text = "Иконки рабочего стола: видно";
            this.roundedButton3.UseVisualStyleBackColor = false;
            this.roundedButton3.Click += new System.EventHandler(this.button9_Click);
            this.roundedButton3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.roundedButton3.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.roundedButton3.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.roundedButton3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // roundedButton2
            // 
            this.roundedButton2.BackColor = System.Drawing.Color.Black;
            this.roundedButton2.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.roundedButton2.Location = new System.Drawing.Point(47, 132);
            this.roundedButton2.Name = "roundedButton2";
            this.roundedButton2.Size = new System.Drawing.Size(292, 53);
            this.roundedButton2.TabIndex = 22;
            this.roundedButton2.Text = "Панель задач: видно";
            this.roundedButton2.UseVisualStyleBackColor = false;
            this.roundedButton2.Click += new System.EventHandler(this.button8_Click);
            this.roundedButton2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.roundedButton2.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.roundedButton2.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.roundedButton2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // roundedButton7
            // 
            this.roundedButton7.BackColor = System.Drawing.Color.Black;
            this.roundedButton7.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.roundedButton7.Location = new System.Drawing.Point(422, 91);
            this.roundedButton7.Name = "roundedButton7";
            this.roundedButton7.Size = new System.Drawing.Size(292, 53);
            this.roundedButton7.TabIndex = 22;
            this.roundedButton7.Text = "Закрыть";
            this.roundedButton7.UseVisualStyleBackColor = false;
            this.roundedButton7.Click += new System.EventHandler(this.button13_Click);
            this.roundedButton7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.roundedButton7.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.roundedButton7.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.roundedButton7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // roundedButton6
            // 
            this.roundedButton6.BackColor = System.Drawing.Color.Black;
            this.roundedButton6.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.roundedButton6.Location = new System.Drawing.Point(422, 32);
            this.roundedButton6.Name = "roundedButton6";
            this.roundedButton6.Size = new System.Drawing.Size(292, 53);
            this.roundedButton6.TabIndex = 22;
            this.roundedButton6.Text = "Открыть";
            this.roundedButton6.UseVisualStyleBackColor = false;
            this.roundedButton6.Click += new System.EventHandler(this.button12_Click);
            this.roundedButton6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.roundedButton6.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.roundedButton6.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.roundedButton6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // roundedButton1
            // 
            this.roundedButton1.BackColor = System.Drawing.Color.Black;
            this.roundedButton1.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.roundedButton1.Location = new System.Drawing.Point(47, 65);
            this.roundedButton1.Name = "roundedButton1";
            this.roundedButton1.Size = new System.Drawing.Size(292, 53);
            this.roundedButton1.TabIndex = 22;
            this.roundedButton1.Text = "Часы: видно";
            this.roundedButton1.UseVisualStyleBackColor = false;
            this.roundedButton1.Click += new System.EventHandler(this.button7_Click);
            this.roundedButton1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.roundedButton1.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.roundedButton1.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.roundedButton1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(441, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 13);
            this.label14.TabIndex = 6;
            this.label14.Text = "CD дисковод";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(106, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Элементы Windows";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Black;
            this.tabPage4.Controls.Add(this.roundedButton8);
            this.tabPage4.Controls.Add(this.comboBox4);
            this.tabPage4.Controls.Add(this.textBox4);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Controls.Add(this.listView2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(901, 550);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Процессы";
            // 
            // roundedButton8
            // 
            this.roundedButton8.BackColor = System.Drawing.Color.Black;
            this.roundedButton8.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.roundedButton8.Location = new System.Drawing.Point(425, 443);
            this.roundedButton8.Name = "roundedButton8";
            this.roundedButton8.Size = new System.Drawing.Size(292, 53);
            this.roundedButton8.TabIndex = 23;
            this.roundedButton8.Text = "Создать процесс";
            this.roundedButton8.UseVisualStyleBackColor = false;
            this.roundedButton8.Click += new System.EventHandler(this.button14_Click);
            this.roundedButton8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.roundedButton8.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.roundedButton8.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.roundedButton8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Normal",
            "Hidden"});
            this.comboBox4.Location = new System.Drawing.Point(298, 460);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 21);
            this.comboBox4.TabIndex = 5;
            this.comboBox4.Text = "Видимость";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(96, 460);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(196, 20);
            this.textBox4.TabIndex = 4;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(23, 463);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 13);
            this.label17.TabIndex = 3;
            this.label17.Text = "Имя файла";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 435);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(129, 13);
            this.label16.TabIndex = 2;
            this.label16.Text = "Создать новый процесс";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(8, 12);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(167, 13);
            this.label15.TabIndex = 1;
            this.label15.Text = "Список запущенных процессов";
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.Color.Black;
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11});
            this.listView2.ContextMenuStrip = this.contextMenuStrip2;
            this.listView2.ForeColor = System.Drawing.Color.White;
            this.listView2.FullRowSelect = true;
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(26, 28);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(867, 375);
            this.listView2.TabIndex = 0;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Название";
            this.columnHeader6.Width = 200;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "PID";
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Ответ";
            this.columnHeader8.Width = 70;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Заголовок";
            this.columnHeader9.Width = 120;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Приоритет";
            this.columnHeader10.Width = 100;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Путь";
            this.columnHeader11.Width = 300;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.killToolStripMenuItem,
            this.refreshToolStripMenuItem1});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(129, 48);
            // 
            // killToolStripMenuItem
            // 
            this.killToolStripMenuItem.Name = "killToolStripMenuItem";
            this.killToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.killToolStripMenuItem.Text = "Закрыть";
            this.killToolStripMenuItem.Click += new System.EventHandler(this.killToolStripMenuItem_Click);
            // 
            // refreshToolStripMenuItem1
            // 
            this.refreshToolStripMenuItem1.Name = "refreshToolStripMenuItem1";
            this.refreshToolStripMenuItem1.Size = new System.Drawing.Size(128, 22);
            this.refreshToolStripMenuItem1.Text = "Обновить";
            this.refreshToolStripMenuItem1.Click += new System.EventHandler(this.refreshToolStripMenuItem1_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Black;
            this.tabPage5.Controls.Add(this.button15);
            this.tabPage5.Controls.Add(this.textBox5);
            this.tabPage5.Controls.Add(this.richTextBox2);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(901, 550);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Удаленная консоль";
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Black;
            this.button15.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button15.Location = new System.Drawing.Point(8, 9);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(292, 53);
            this.button15.TabIndex = 23;
            this.button15.Text = "Запустить Cmd";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            this.button15.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.button15.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.button15.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.button15.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(8, 469);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(885, 20);
            this.textBox5.TabIndex = 2;
            this.textBox5.Tag = "rcmd";
            this.textBox5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox5_KeyDown);
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.Black;
            this.richTextBox2.ForeColor = System.Drawing.Color.White;
            this.richTextBox2.Location = new System.Drawing.Point(8, 72);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(885, 395);
            this.richTextBox2.TabIndex = 1;
            this.richTextBox2.Text = "";
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.Black;
            this.tabPage8.Controls.Add(this.lblQualityShow);
            this.tabPage8.Controls.Add(this.lblChooseScreen);
            this.tabPage8.Controls.Add(this.cmboChooseScreen);
            this.tabPage8.Controls.Add(this.btnCountScreens);
            this.tabPage8.Controls.Add(this.btnStartTaskManager);
            this.tabPage8.Controls.Add(this.txtBControlKeyboard);
            this.tabPage8.Controls.Add(this.label34);
            this.tabPage8.Controls.Add(this.trackBar1);
            this.tabPage8.Controls.Add(this.btnFullScreenMode);
            this.tabPage8.Controls.Add(this.checkBoxrKeyboard);
            this.tabPage8.Controls.Add(this.checkBoxrMouse);
            this.tabPage8.Controls.Add(this.button22);
            this.tabPage8.Controls.Add(this.button21);
            this.tabPage8.Controls.Add(this.pictureBox1);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(901, 550);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Рабочий стол";
            // 
            // lblQualityShow
            // 
            this.lblQualityShow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblQualityShow.AutoSize = true;
            this.lblQualityShow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.lblQualityShow.Location = new System.Drawing.Point(661, 530);
            this.lblQualityShow.Name = "lblQualityShow";
            this.lblQualityShow.Size = new System.Drawing.Size(33, 13);
            this.lblQualityShow.TabIndex = 21;
            this.lblQualityShow.Text = "(best)";
            // 
            // lblChooseScreen
            // 
            this.lblChooseScreen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblChooseScreen.AutoSize = true;
            this.lblChooseScreen.Location = new System.Drawing.Point(466, 521);
            this.lblChooseScreen.Name = "lblChooseScreen";
            this.lblChooseScreen.Size = new System.Drawing.Size(97, 13);
            this.lblChooseScreen.TabIndex = 20;
            this.lblChooseScreen.Text = "Выбрать монитор";
            // 
            // cmboChooseScreen
            // 
            this.cmboChooseScreen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cmboChooseScreen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmboChooseScreen.FormattingEnabled = true;
            this.cmboChooseScreen.Location = new System.Drawing.Point(569, 516);
            this.cmboChooseScreen.Name = "cmboChooseScreen";
            this.cmboChooseScreen.Size = new System.Drawing.Size(75, 21);
            this.cmboChooseScreen.TabIndex = 19;
            // 
            // btnCountScreens
            // 
            this.btnCountScreens.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCountScreens.ForeColor = System.Drawing.Color.Black;
            this.btnCountScreens.Location = new System.Drawing.Point(469, 485);
            this.btnCountScreens.Name = "btnCountScreens";
            this.btnCountScreens.Size = new System.Drawing.Size(175, 23);
            this.btnCountScreens.TabIndex = 18;
            this.btnCountScreens.Text = "Посчитать мониторы";
            this.btnCountScreens.UseVisualStyleBackColor = true;
            this.btnCountScreens.Click += new System.EventHandler(this.btnCountScreens_Click);
            // 
            // btnStartTaskManager
            // 
            this.btnStartTaskManager.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnStartTaskManager.Enabled = false;
            this.btnStartTaskManager.ForeColor = System.Drawing.Color.Black;
            this.btnStartTaskManager.Location = new System.Drawing.Point(295, 485);
            this.btnStartTaskManager.Name = "btnStartTaskManager";
            this.btnStartTaskManager.Size = new System.Drawing.Size(165, 23);
            this.btnStartTaskManager.TabIndex = 17;
            this.btnStartTaskManager.Text = "Запустить диспетчер задач";
            this.btnStartTaskManager.UseVisualStyleBackColor = true;
            this.btnStartTaskManager.Click += new System.EventHandler(this.btnStartTaskManager_Click);
            // 
            // txtBControlKeyboard
            // 
            this.txtBControlKeyboard.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtBControlKeyboard.BackColor = System.Drawing.SystemColors.Window;
            this.txtBControlKeyboard.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBControlKeyboard.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtBControlKeyboard.ForeColor = System.Drawing.SystemColors.Window;
            this.txtBControlKeyboard.Location = new System.Drawing.Point(197, 489);
            this.txtBControlKeyboard.Multiline = true;
            this.txtBControlKeyboard.Name = "txtBControlKeyboard";
            this.txtBControlKeyboard.Size = new System.Drawing.Size(94, 20);
            this.txtBControlKeyboard.TabIndex = 16;
            this.txtBControlKeyboard.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBControlKeyboard_KeyDown);
            // 
            // label34
            // 
            this.label34.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(698, 482);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(154, 13);
            this.label34.TabIndex = 15;
            this.label34.Text = "Частота обновления экрана:";
            // 
            // trackBar1
            // 
            this.trackBar1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.trackBar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.trackBar1.Location = new System.Drawing.Point(650, 498);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Minimum = 1;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(243, 45);
            this.trackBar1.TabIndex = 14;
            this.trackBar1.Value = 75;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // btnFullScreenMode
            // 
            this.btnFullScreenMode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnFullScreenMode.Enabled = false;
            this.btnFullScreenMode.ForeColor = System.Drawing.Color.Black;
            this.btnFullScreenMode.Location = new System.Drawing.Point(295, 514);
            this.btnFullScreenMode.Name = "btnFullScreenMode";
            this.btnFullScreenMode.Size = new System.Drawing.Size(165, 23);
            this.btnFullScreenMode.TabIndex = 5;
            this.btnFullScreenMode.Text = "Полноэкранный";
            this.btnFullScreenMode.UseVisualStyleBackColor = true;
            this.btnFullScreenMode.Click += new System.EventHandler(this.btnFullRemoteScreen_Click);
            // 
            // checkBoxrKeyboard
            // 
            this.checkBoxrKeyboard.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBoxrKeyboard.AutoSize = true;
            this.checkBoxrKeyboard.Location = new System.Drawing.Point(84, 517);
            this.checkBoxrKeyboard.Name = "checkBoxrKeyboard";
            this.checkBoxrKeyboard.Size = new System.Drawing.Size(137, 17);
            this.checkBoxrKeyboard.TabIndex = 4;
            this.checkBoxrKeyboard.Text = "Контроль клавиатуры";
            this.checkBoxrKeyboard.UseVisualStyleBackColor = true;
            this.checkBoxrKeyboard.CheckedChanged += new System.EventHandler(this.checkBoxrKeyboard_CheckedChanged);
            // 
            // checkBoxrMouse
            // 
            this.checkBoxrMouse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBoxrMouse.AutoSize = true;
            this.checkBoxrMouse.Location = new System.Drawing.Point(84, 489);
            this.checkBoxrMouse.Name = "checkBoxrMouse";
            this.checkBoxrMouse.Size = new System.Drawing.Size(107, 17);
            this.checkBoxrMouse.TabIndex = 3;
            this.checkBoxrMouse.Text = "Контроль мыши";
            this.checkBoxrMouse.UseVisualStyleBackColor = true;
            this.checkBoxrMouse.CheckedChanged += new System.EventHandler(this.checkBoxrMouse_CheckedChanged);
            // 
            // button22
            // 
            this.button22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button22.ForeColor = System.Drawing.Color.Black;
            this.button22.Location = new System.Drawing.Point(3, 513);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(75, 23);
            this.button22.TabIndex = 2;
            this.button22.Text = "Стоп";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.btnStopRemoteScreen_Click);
            // 
            // button21
            // 
            this.button21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button21.ForeColor = System.Drawing.Color.Black;
            this.button21.Location = new System.Drawing.Point(3, 487);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(75, 23);
            this.button21.TabIndex = 1;
            this.button21.Text = "Запуск";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.btnStartRemoteScreen_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Location = new System.Drawing.Point(8, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(890, 476);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "rdesktop";
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.Color.Black;
            this.tabPage9.Controls.Add(this.button25);
            this.tabPage9.Controls.Add(this.roundedButton10);
            this.tabPage9.Controls.Add(this.listView4);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(901, 550);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Аудио";
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Black;
            this.button25.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button25.Location = new System.Drawing.Point(306, 466);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(292, 53);
            this.button25.TabIndex = 23;
            this.button25.Text = "Слушать";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            this.button25.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.button25.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.button25.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.button25.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // roundedButton10
            // 
            this.roundedButton10.BackColor = System.Drawing.Color.Black;
            this.roundedButton10.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.roundedButton10.Location = new System.Drawing.Point(8, 466);
            this.roundedButton10.Name = "roundedButton10";
            this.roundedButton10.Size = new System.Drawing.Size(292, 53);
            this.roundedButton10.TabIndex = 23;
            this.roundedButton10.Text = "Обновить список";
            this.roundedButton10.UseVisualStyleBackColor = false;
            this.roundedButton10.Click += new System.EventHandler(this.button24_Click);
            this.roundedButton10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.roundedButton10.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.roundedButton10.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.roundedButton10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // listView4
            // 
            this.listView4.BackColor = System.Drawing.Color.Black;
            this.listView4.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader16,
            this.columnHeader17});
            this.listView4.ForeColor = System.Drawing.Color.White;
            this.listView4.FullRowSelect = true;
            this.listView4.HideSelection = false;
            this.listView4.Location = new System.Drawing.Point(8, 15);
            this.listView4.MultiSelect = false;
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(890, 445);
            this.listView4.TabIndex = 1;
            this.listView4.UseCompatibleStateImageBehavior = false;
            this.listView4.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Название";
            this.columnHeader16.Width = 376;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Каналы";
            this.columnHeader17.Width = 83;
            // 
            // tabPage10
            // 
            this.tabPage10.BackColor = System.Drawing.Color.Black;
            this.tabPage10.Controls.Add(this.button27);
            this.tabPage10.Controls.Add(this.roundedButton12);
            this.tabPage10.Controls.Add(this.listView5);
            this.tabPage10.Controls.Add(this.pictureBox2);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(901, 550);
            this.tabPage10.TabIndex = 9;
            this.tabPage10.Text = "Видео";
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Black;
            this.button27.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button27.Location = new System.Drawing.Point(596, 256);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(297, 53);
            this.button27.TabIndex = 23;
            this.button27.Text = "Смотреть";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            this.button27.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.button27.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.button27.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.button27.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // roundedButton12
            // 
            this.roundedButton12.BackColor = System.Drawing.Color.Black;
            this.roundedButton12.Font = new System.Drawing.Font("Minecraft Rus", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.roundedButton12.Location = new System.Drawing.Point(596, 197);
            this.roundedButton12.Name = "roundedButton12";
            this.roundedButton12.Size = new System.Drawing.Size(297, 53);
            this.roundedButton12.TabIndex = 23;
            this.roundedButton12.Text = "Список камер";
            this.roundedButton12.UseVisualStyleBackColor = false;
            this.roundedButton12.Click += new System.EventHandler(this.button26_Click);
            this.roundedButton12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseDown);
            this.roundedButton12.MouseEnter += new System.EventHandler(this.roundedButton_MouseEnter);
            this.roundedButton12.MouseLeave += new System.EventHandler(this.roundedButton_MouseLeave);
            this.roundedButton12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.roundedButton_MouseUp);
            // 
            // listView5
            // 
            this.listView5.BackColor = System.Drawing.Color.Black;
            this.listView5.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader18,
            this.columnHeader19});
            this.listView5.ForeColor = System.Drawing.Color.White;
            this.listView5.FullRowSelect = true;
            this.listView5.HideSelection = false;
            this.listView5.Location = new System.Drawing.Point(596, 3);
            this.listView5.MultiSelect = false;
            this.listView5.Name = "listView5";
            this.listView5.Size = new System.Drawing.Size(302, 188);
            this.listView5.TabIndex = 1;
            this.listView5.UseCompatibleStateImageBehavior = false;
            this.listView5.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "ID";
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "Название";
            this.columnHeader19.Width = 233;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(8, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(582, 491);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Tag = "wcstream";
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listDrivesToolStripMenuItem,
            this.enterDirectoryToolStripMenuItem,
            this.toolStripMenuItem1,
            this.moveToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.executeToolStripMenuItem,
            this.uploadToolStripMenuItem,
            this.downloadToolStripMenuItem,
            this.editToolStripMenuItem,
            this.attributesToolStripMenuItem,
            this.deleteToolStripMenuItem,
            this.renameToolStripMenuItem,
            this.newToolStripMenuItem});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(153, 312);
            // 
            // listDrivesToolStripMenuItem
            // 
            this.listDrivesToolStripMenuItem.Name = "listDrivesToolStripMenuItem";
            this.listDrivesToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.listDrivesToolStripMenuItem.Text = "List Drives";
            this.listDrivesToolStripMenuItem.Click += new System.EventHandler(this.listDrivesToolStripMenuItem_Click);
            // 
            // enterDirectoryToolStripMenuItem
            // 
            this.enterDirectoryToolStripMenuItem.Name = "enterDirectoryToolStripMenuItem";
            this.enterDirectoryToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.enterDirectoryToolStripMenuItem.Text = "Enter Directory";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.toolStripMenuItem1.Text = "Up 1 Directory";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // moveToolStripMenuItem
            // 
            this.moveToolStripMenuItem.Name = "moveToolStripMenuItem";
            this.moveToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.moveToolStripMenuItem.Text = "Move";
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.currentDirectoryToolStripMenuItem,
            this.selectedDirectoryToolStripMenuItem});
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.pasteToolStripMenuItem.Text = "Paste";
            // 
            // currentDirectoryToolStripMenuItem
            // 
            this.currentDirectoryToolStripMenuItem.Name = "currentDirectoryToolStripMenuItem";
            this.currentDirectoryToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.currentDirectoryToolStripMenuItem.Text = "Current Directory";
            this.currentDirectoryToolStripMenuItem.Click += new System.EventHandler(this.currentDirectoryToolStripMenuItem_Click);
            // 
            // selectedDirectoryToolStripMenuItem
            // 
            this.selectedDirectoryToolStripMenuItem.Name = "selectedDirectoryToolStripMenuItem";
            this.selectedDirectoryToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.selectedDirectoryToolStripMenuItem.Text = "Selected Directory";
            // 
            // executeToolStripMenuItem
            // 
            this.executeToolStripMenuItem.Name = "executeToolStripMenuItem";
            this.executeToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.executeToolStripMenuItem.Text = "Execute";
            // 
            // uploadToolStripMenuItem
            // 
            this.uploadToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.currentDirectoryToolStripMenuItem1,
            this.selectedDirectoryToolStripMenuItem1});
            this.uploadToolStripMenuItem.Name = "uploadToolStripMenuItem";
            this.uploadToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.uploadToolStripMenuItem.Text = "Upload";
            // 
            // currentDirectoryToolStripMenuItem1
            // 
            this.currentDirectoryToolStripMenuItem1.Name = "currentDirectoryToolStripMenuItem1";
            this.currentDirectoryToolStripMenuItem1.Size = new System.Drawing.Size(169, 22);
            this.currentDirectoryToolStripMenuItem1.Text = "Current Directory";
            this.currentDirectoryToolStripMenuItem1.Click += new System.EventHandler(this.currentDirectoryToolStripMenuItem1_Click);
            // 
            // selectedDirectoryToolStripMenuItem1
            // 
            this.selectedDirectoryToolStripMenuItem1.Name = "selectedDirectoryToolStripMenuItem1";
            this.selectedDirectoryToolStripMenuItem1.Size = new System.Drawing.Size(169, 22);
            this.selectedDirectoryToolStripMenuItem1.Text = "Selected Directory";
            // 
            // downloadToolStripMenuItem
            // 
            this.downloadToolStripMenuItem.Name = "downloadToolStripMenuItem";
            this.downloadToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.downloadToolStripMenuItem.Text = "Download";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // attributesToolStripMenuItem
            // 
            this.attributesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hideToolStripMenuItem,
            this.showToolStripMenuItem});
            this.attributesToolStripMenuItem.Name = "attributesToolStripMenuItem";
            this.attributesToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.attributesToolStripMenuItem.Text = "Attributes";
            // 
            // hideToolStripMenuItem
            // 
            this.hideToolStripMenuItem.Name = "hideToolStripMenuItem";
            this.hideToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.hideToolStripMenuItem.Text = "Hide";
            // 
            // showToolStripMenuItem
            // 
            this.showToolStripMenuItem.Name = "showToolStripMenuItem";
            this.showToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.showToolStripMenuItem.Text = "Show";
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            // 
            // renameToolStripMenuItem
            // 
            this.renameToolStripMenuItem.Name = "renameToolStripMenuItem";
            this.renameToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.renameToolStripMenuItem.Text = "Rename";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.directoryToolStripMenuItem});
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.newToolStripMenuItem.Text = "New";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.fileToolStripMenuItem.Text = "File";
            this.fileToolStripMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // directoryToolStripMenuItem
            // 
            this.directoryToolStripMenuItem.Name = "directoryToolStripMenuItem";
            this.directoryToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.directoryToolStripMenuItem.Text = "Directory";
            this.directoryToolStripMenuItem.Click += new System.EventHandler(this.directoryToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(909, 576);
            this.Controls.Add(this.tabControl1);
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.Name = "Form1";
            this.Text = "RAT сервер";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.contextMenuStrip3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem killToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem listDrivesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enterDirectoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem moveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem executeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uploadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem downloadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem attributesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hideToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem renameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem directoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem currentDirectoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectedDirectoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem currentDirectoryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem selectedDirectoryToolStripMenuItem1;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Button btnFullScreenMode;
        public System.Windows.Forms.CheckBox checkBoxrKeyboard;
        public System.Windows.Forms.CheckBox checkBoxrMouse;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.ListView listView5;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label24;
        public System.Windows.Forms.Label lblQualityShow;
        private System.Windows.Forms.Label lblChooseScreen;
        private System.Windows.Forms.ComboBox cmboChooseScreen;
        private System.Windows.Forms.Button btnCountScreens;
        private System.Windows.Forms.Button btnStartTaskManager;
        private System.Windows.Forms.TextBox txtBControlKeyboard;
        private System.Windows.Forms.Label label34;
        public System.Windows.Forms.TrackBar trackBar1;
        private RoundedButton button2;
        private RoundedButton button5;
        private RoundedButton button6;
        private RoundedButton button4;
        private RoundedButton button3;
        private RoundedButton button1;
        private RoundedButton roundedButton5;
        private RoundedButton roundedButton4;
        private RoundedButton roundedButton3;
        private RoundedButton roundedButton2;
        private RoundedButton roundedButton1;
        private RoundedButton roundedButton7;
        private RoundedButton roundedButton6;
        private RoundedButton roundedButton8;
        private RoundedButton button15;
        private RoundedButton button25;
        private RoundedButton roundedButton10;
        private RoundedButton button27;
        private RoundedButton roundedButton12;
    }
}

