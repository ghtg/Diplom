public string Encrypt(string clearText)
{
    string encryptionKey = "MAKV2SPBNI99212"; //Declare the AES encryption key (it's not the best thing to do)
    string blowfishKey = "BLOWFISHKEY"; //Declare the Blowfish encryption key

    byte[] clearBytes = Encoding.Unicode.GetBytes(clearText); //Get the bytes of the message

    using (Aes aes = Aes.Create()) //Create a new AES object
    {
        Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(encryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 }); //Get AES encryption key
        aes.Key = pdb.GetBytes(32); //Set the AES encryption key
        aes.IV = pdb.GetBytes(16); //Set the AES encryption IV

        using (MemoryStream ms = new MemoryStream()) //Create a new memory stream
        {
            using (CryptoStream cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write)) //Create a new AES crypto stream
            {
                cs.Write(clearBytes, 0, clearBytes.Length); //Write the command to the AES crypto stream
                cs.Close(); //Close the AES crypto stream
            }

            byte[] encryptedBytes = ms.ToArray(); //Get the encrypted bytes from the AES crypto stream

            using (Blowfish blowfish = new Blowfish(Encoding.UTF8.GetBytes(blowfishKey))) //Create a new Blowfish object with the key
            {
                byte[] encryptedBlowfish = blowfish.Encrypt_CBC(encryptedBytes); //Encrypt the AES encrypted bytes using Blowfish in CBC mode
                string base64EncryptedBlowfish = Convert.ToBase64String(encryptedBlowfish); //Convert the encrypted bytes to a Base64 string
                return base64EncryptedBlowfish; //Return the encrypted command
            }
        }
    }
}
